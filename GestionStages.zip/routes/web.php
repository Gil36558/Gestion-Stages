<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\EntrepriseController;
use App\Http\Controllers\OffreController;
use App\Http\Controllers\DemandeStageController;
use App\Http\Controllers\CandidatureController;

// Page d'accueil (publique)
Route::get('/', function () {
    return view('welcome');
})->name('welcome');

// Routes d'authentification
require __DIR__.'/auth.php';

// Routes protégées par authentification
Route::middleware(['auth', 'verified'])->group(function () {
    // Redirection dashboard selon rôle
    Route::get('/dashboard', function () {
        return auth()->user()->role === 'etudiant'
            ? redirect()->route('etudiant.dashboard')
            : (auth()->user()->role === 'entreprise' ? redirect()->route('entreprise.dashboard') : abort(403, 'Rôle non reconnu'));
    })->name('dashboard');

    // Gestion du profil utilisateur
    Route::prefix('profile')->group(function () {
        Route::get('/', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    // Routes pour les étudiants
    Route::middleware(['checkrole:etudiant'])->group(function () {
        Route::get('/etudiant/dashboard', [EtudiantController::class, 'dashboard'])->name('etudiant.dashboard');

        // Demandes de stage académique
        Route::prefix('demandes')->group(function () {
            Route::get('/create', [DemandeStageController::class, 'create'])->name('demandes.create');
            Route::post('/store', [DemandeStageController::class, 'store'])->name('demandes.store');
        });

        // Candidatures étudiants
        Route::prefix('candidatures')->group(function () {
            Route::post('/store', [CandidatureController::class, 'store'])->name('candidatures.store');
            Route::get('/mes-candidatures', [CandidatureController::class, 'index'])->name('candidatures.index');
        });
    });

    // Routes pour les entreprises
    Route::middleware(['checkrole:entreprise'])->group(function () {
        Route::get('/entreprise/dashboard', [EntrepriseController::class, 'dashboard'])->name('entreprise.dashboard');

        // Gestion du profil entreprise
        Route::get('/entreprise/create', [EntrepriseController::class, 'create'])->name('entreprise.create');
        Route::post('/entreprise/store', [EntrepriseController::class, 'store'])->name('entreprise.store');
        Route::get('/entreprise/{entreprise}/edit', [EntrepriseController::class, 'edit'])->name('entreprise.edit');
        Route::put('/entreprise/{entreprise}', [EntrepriseController::class, 'update'])->name('entreprise.update');

        // Gestion des offres
        Route::prefix('entreprise/offres')->group(function () {
            Route::get('/create', [OffreController::class, 'create'])->name('entreprise.offres.create');
            Route::post('/store', [OffreController::class, 'store'])->name('entreprise.offres.store');
            Route::get('/{offre}/edit', [OffreController::class, 'edit'])->name('entreprise.offres.edit');
            Route::put('/{offre}', [OffreController::class, 'update'])->name('entreprise.offres.update');
            Route::delete('/{offre}', [OffreController::class, 'destroy'])->name('entreprise.offres.destroy');
        });

        // Gestion des candidatures reçues
        Route::get('/entreprise/candidatures', [EntrepriseController::class, 'candidatures'])->name('entreprise.candidatures');
        Route::patch('/entreprise/candidatures/{candidature}', [EntrepriseController::class, 'updateCandidature'])->name('entreprise.candidatures.update');

        // Actions spécifiques sur les candidatures
        Route::patch('/entreprise/candidatures/{candidature}/approve', [EntrepriseController::class, 'approveCandidature'])->name('entreprise.candidatures.approve');
        Route::patch('/entreprise/candidatures/{candidature}/reject', [EntrepriseController::class, 'rejectCandidature'])->name('entreprise.candidatures.reject');
    });

    // Routes communes aux deux rôles
    Route::get('/offres', [OffreController::class, 'index'])->name('offres.index');
    Route::get('/offres/{offre}', [OffreController::class, 'show'])->name('offres.show');
    Route::get('/entreprises', [EntrepriseController::class, 'index'])->name('entreprises.index');
    Route::get('/entreprises/{entreprise}', [EntrepriseController::class, 'show'])->name('entreprises.show');
});
