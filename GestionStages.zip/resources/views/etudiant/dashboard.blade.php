@extends('layouts.app')

@section('title', 'Tableau de bord Étudiant')

@push('styles')
<style>
    .dashboard-card {
        transition: 0.3s ease;
    }
    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
    .card-icon {
        font-size: 2rem;
    }
</style>
@endpush

@section('content')
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold">Bienvenue, {{ Auth::user()->name }}</h4>
            <p class="text-muted">Vous êtes connecté en tant qu’Étudiant.</p>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card dashboard-card text-white bg-primary">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-file-earmark-text card-icon me-3"></i>
                        <div>
                            <h6 class="mb-0">Total de demandes</h6>
                            <h4 class="mb-0">0</h4> <!-- à remplacer par une variable dynamique -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card dashboard-card text-white bg-success">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-check-circle card-icon me-3"></i>
                        <div>
                            <h6 class="mb-0">Demandes acceptées</h6>
                            <h4 class="mb-0">0</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card dashboard-card text-white bg-warning">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-hourglass-split card-icon me-3"></i>
                        <div>
                            <h6 class="mb-0">En attente</h6>
                            <h4 class="mb-0">0</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card dashboard-card text-white bg-info">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-journal-text card-icon me-3"></i>
                        <div>
                            <h6 class="mb-0">Stages disponibles</h6>
                            <h4 class="mb-0">0</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-light fw-semibold">
            Actions rapides
        </div>
        <div class="card-body">
            <div class="d-grid gap-3">
                <a href="{{ route('demande.create') }}" class="btn btn-outline-primary">
                    <i class="bi bi-plus-circle"></i> Nouvelle demande de stage académique
                </a>
                <a href="#" class="btn btn-outline-secondary">
                    <i class="bi bi-folder2-open"></i> Consulter vos stages en cours
                </a>
                <a href="#" class="btn btn-outline-dark">
                    <i class="bi bi-journal-text"></i> Remplir votre journal de suivi
                </a>
            </div>
        </div>
    </div>
</div>
@endsection
