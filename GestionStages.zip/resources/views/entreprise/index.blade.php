@extends('layouts.app')

@section('content')
<h1>Liste des entreprises</h1>

<a href="{{ route('entreprises.create') }}" class="btn btn-primary mb-3">Ajouter une entreprise</a>

@if(session('success'))
<div class="alert alert-success">{{ session('success') }}</div>
@endif

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Email</th>
            <th>Adresse</th>
            <th>Téléphone</th>
        </tr>
    </thead>
    <tbody>
        @foreach($entreprises as $entreprise)
        <tr>
            <td>{{ $entreprise->nom }}</td>
            <td>{{ $entreprise->email }}</td>
            <td>{{ $entreprise->adresse }}</td>
            <td>{{ $entreprise->telephone }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection
