@extends('layouts.app')

@section('title', 'Tableau de bord - PlateformeStages')

@push('styles')
<!-- AOS CSS -->
<link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
<!-- Tailwind CSS CDN -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

    :root {
        --primary-blue: #2563eb;
        --primary-dark: #1e40af;
        --primary-light: #3b82f6;
        --secondary-blue: #eff6ff;
        --success-color: #10b981;
        --danger-color: #ef4444;
        --text-primary: #1f2937;
        --text-secondary: #6b7280;
        --background: #ffffff;
        --background-alt: #f8fafc;
        --border-color: #e5e7eb;
        --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }

    .dashboard-container {
        min-height: calc(100vh - 80px);
        padding: 2rem 1rem;
        background: linear-gradient(135deg, var(--secondary-blue) 0%, #ffffff 100%);
        display: flex;
        justify-content: center;
    }

    .dashboard-card {
        background: var(--background);
        border-radius: 20px;
        box-shadow: var(--shadow-xl);
        border: 1px solid rgba(255, 255, 255, 0.2);
        width: 100%;
        max-width: 1000px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .dashboard-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3);
    }

    .dashboard-header {
        background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-light) 100%);
        padding: 2rem;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .dashboard-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
        animation: shimmer 3s infinite;
    }

    @keyframes shimmer {
        0%, 100% { transform: translateX(-100%) translateY(-100%) rotate(0deg); }
        50% { transform: translateX(0%) translateY(0%) rotate(180deg); }
    }

    .dashboard-header h1 {
        font-size: 2rem;
        font-weight: 700;
        color: white;
        margin: 0;
        position: relative;
        z-index: 1;
    }

    .dashboard-body {
        padding: 2rem;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: var(--background-alt);
        padding: 1.5rem;
        border-radius: 12px;
        text-align: center;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        background: var(--secondary-blue);
        transform: translateY(-2px);
    }

    .table-responsive {
        overflow-x: auto;
    }

    .candidates-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 0.5rem;
    }

    .candidates-table th,
    .candidates-table td {
        padding: 1rem;
        text-align: left;
        background: var(--background);
    }

    .candidates-table th {
        background: var(--primary-blue);
        color: white;
        font-weight: 600;
    }

    .candidates-table tr {
        box-shadow: var(--shadow-sm);
        transition: all 0.3s ease;
    }

    .candidates-table tr:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }

    .action-btn {
        padding: 0.5rem 1rem;
        border-radius: 50px;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-approve {
        background: var(--success-color);
        color: white;
    }

    .btn-approve:hover {
        background: #047857;
    }

    .btn-reject {
        background: var(--danger-color);
        color: white;
    }

    .btn-reject:hover {
        background: #dc2626;
    }

    @media (max-width: 768px) {
        .dashboard-container {
            padding: 1rem;
        }
        .dashboard-body {
            padding: 1rem;
        }
        .stats-grid {
            grid-template-columns: 1fr;
        }
        .candidates-table th,
        .candidates-table td {
            padding: 0.75rem;
        }
    }
</style>
@endpush

@section('content')
<div class="dashboard-container">
    <div class="dashboard-card" data-aos="fade-up" data-aos-duration="800">
        <div class="dashboard-header">
            <h1>Tableau de bord - Entreprise</h1>
        </div>
        <div class="dashboard-body">
            @if (isset($incompleteProfile) && $incompleteProfile)
                <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <strong class="font-bold">Attention !</strong>
                    <span class="block sm:inline"> Votre profil entreprise n'est pas complété. <a href="{{ route('entreprise.create') }}" class="underline">Complétez-le maintenant</a>.</span>
                </div>
            @else
                <!-- Statistiques rapides -->
                <div class="stats-grid" data-aos="fade-up" data-aos-delay="100">
                    <div class="stat-card">
                        <h3 class="text-lg font-semibold text-gray-700">Offres publiées</h3>
                        <p class="text-2xl font-bold text-primary-blue">{{ $stats['offres'] }}</p>
                    </div>
                    <div class="stat-card">
                        <h3 class="text-lg font-semibold text-gray-700">Candidatures reçues</h3>
                        <p class="text-2xl font-bold text-primary-blue">{{ $stats['candidatures'] }}</p>
                    </div>
                </div>

                <!-- Tableau des candidatures -->
                <div class="table-responsive" data-aos="fade-up" data-aos-delay="200">
                    <table class="candidates-table">
                        <thead>
                            <tr>
                                <th>Étudiant</th>
                                <th>Offre</th>
                                <th>Date</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($stats['candidatures_recentes'] as $candidature)
                                <tr>
                                    <td>{{ $candidature->etudiant->user->name ?? 'N/A' }}</td>
                                    <td>{{ $candidature->offre->titre ?? 'N/A' }}</td>
                                    <td>{{ $candidature->created_at->format('d/m/Y') }}</td>
                                    <td>{{ $candidature->statut ?? 'En attente' }}</td>
                                    <td>
                                        <a href="{{ route('entreprise.candidature.approve', $candidature->id) }}" class="action-btn btn-approve mr-2">Valider</a>
                                        <a href="{{ route('entreprise.candidature.reject', $candidature->id) }}" class="action-btn btn-reject">Rejeter</a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-gray-500">Aucune candidature récente pour le moment.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- Bouton pour ajouter une offre -->
                <div class="mt-6 text-center" data-aos="fade-up" data-aos-delay="300">
                    <a href="{{ route('enterprise.offre.create') }}" class="btn-primary">Publier une nouvelle offre</a>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({
        once: true,
        offset: 100,
        duration: 800,
        easing: 'ease-out-cubic',
    });
</script>
@endpush