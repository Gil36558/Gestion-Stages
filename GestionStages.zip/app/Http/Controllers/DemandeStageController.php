<?php

namespace App\Http\Controllers;

use App\Models\DemandeStage;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DemandeStageController extends Controller
{
    /**
     * Affiche le formulaire de création d'une demande de stage académique
     */
    public function create()
    {
        // Liste des étudiants sauf soi-même (pour binôme/trinôme)
        $etudiants = User::where('role', 'etudiant')
                         ->where('id', '!=', Auth::id())
                         ->get();

        return view('etudiant.demande.create', compact('etudiants'));
    }

    /**
     * Enregistre une nouvelle demande de stage académique
     */
    public function store(Request $request)
    {
        $request->validate([
            'type' => 'required|in:academique',
            'objet' => 'required|string|max:255',
            'periode_debut' => 'required|date',
            'periode_fin' => 'required|date|after_or_equal:periode_debut',
            'membres' => 'array|max:2', // max = binôme ou trinôme
            'membres.*' => 'exists:users,id',
        ]);

        // Création de la demande principale
        $demande = DemandeStage::create([
            'type' => $request->type,
            'objet' => $request->objet,
            'periode_debut' => $request->periode_debut,
            'periode_fin' => $request->periode_fin,
        ]);

        // Attacher l'étudiant principal + les membres du groupe (s'ils existent)
        $etudiantIds = array_merge([Auth::id()], $request->membres ?? []);
        $demande->etudiants()->attach($etudiantIds);

        return redirect()->route('dashboard')->with('success', 'Demande envoyée avec succès !');
    }
}
