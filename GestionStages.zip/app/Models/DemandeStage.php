<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DemandeStage extends Model
{
    public function etudiants()
    {
        return $this->belongsToMany(User::class, 'demande_stage_etudiant', 'demande_id', 'etudiant_id');
    }

    public function suivis()
    {
        return $this->hasMany(SuiviStage::class);
    }

}
