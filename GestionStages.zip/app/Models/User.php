<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable // implements MustVerifyEmail
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'prenom',
        'matricule', 
        'filiere',
        'ecole',
        'date_naissance',
        'telephone',
        'adresse'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'date_naissance' => 'date',
    ];

    /**
     * Relation avec le modèle Entreprise (1-1)
     */
    public function entreprise()
    {
        return $this->hasOne(Entreprise::class);
    }

    /**
     * Relation avec les demandes de stage (many-to-many)
     */
    public function demandesStages()
    {
        return $this->belongsToMany(DemandeStage::class, 'demande_stage_etudiant', 'etudiant_id', 'demande_id')
                    ->withTimestamps();
    }

    /**
     * Relation avec les candidatures (1-n)
     */
    public function candidatures()
    {
        return $this->hasMany(Candidature::class);
    }

    /**
     * Relation avec les offres (pour les entreprises)
     */
    public function offres()
    {
        return $this->hasMany(Offre::class);
    }

    /**
     * Vérifie si l'utilisateur est une entreprise
     */
    public function estEntreprise(): bool
    {
        return $this->role === 'entreprise';
    }

    /**
     * Vérifie si l'utilisateur est un étudiant
     */
    public function estEtudiant(): bool
    {
        return $this->role === 'etudiant';
    }

    /**
     * Scope pour les utilisateurs entreprises
     */
    public function scopeEntreprises($query)
    {
        return $query->where('role', 'entreprise');
    }

    /**
     * Scope pour les utilisateurs étudiants
     */
    public function scopeEtudiants($query)
    {
        return $query->where('role', 'etudiant');
    }
}