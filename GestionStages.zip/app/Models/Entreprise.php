<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Entreprise extends Model
{
    protected $fillable = [
        'nom',
        'email',
        'adresse',
        'telephone',
        'secteur',
        'site_web',
        'description',
    ];

    public function offres()
    {
        return $this->hasMany(Offre::class);
    }
}
